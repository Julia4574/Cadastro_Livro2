<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <title>Página Inicial</title>
     <link rel="stylesheet" type="text/css" href="css/forme.css" media="screen" />
</head>

<body>

    <h1>Bem-vindo!</h1>
    <form action="login.php" method="GET">
        <button type="submit">Login</button>
    </form>
    <br>
    <form action="cadastro.php" method="GET">
        <button type="submit">Cadastro</button>
    </form>

</body>

</html>
